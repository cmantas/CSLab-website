now="$(date +'%d-%m-%Y')"
mysqldump -u cslab_new -p cslab_new --password=pwjW7QPsqQs6QYUA > "cslab_new_site_backup_$now.sql"
tar -zcvf "backup_site_$now.tar.gz" ../cslab

