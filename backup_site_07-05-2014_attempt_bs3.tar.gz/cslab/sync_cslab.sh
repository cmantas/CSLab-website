rsync -a --progress --exclude '*.htaccess' ../cslab cmantas@geronimo.cslab.ece.ntua.gr:/var/www/cmantas_test
