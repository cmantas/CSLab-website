
<script>
		function show_hide( el)
			{
				el.getElementsByClassName("diplom_guide")[0].style.display=
					el.getElementsByClassName("diplom_guide")[0].style.display==="none" ?
						"block" : "none" ;


			}

	</script>	

	<div onclick="show_hide(this);" >
		dfasl;fkjasdl;kfjaslfkjasd;lfkjsda;ljk
<div class="diplom_guide" style="display: none">
	
<h2> Οδηγίες για την Εκπόνηση Διπλωματικών Εργασιών </h2>


<h3> Προσθεμίες </h3>

<p>
  Στο <a href="http://www.ntua.gr/gr_academics/calendar.htm">Ημερολόγιο
  Ακαδημαϊκού Έτους</a> μπορούν να βρεθούν οι προσθεμίες για την <a
  href="http://www.ntua.gr/gr_academics/calendar4.htm">ανάθεση</a> και
  την <a href="http://www.ntua.gr/gr_academics/calendar4.htm">εξέταση</a>
  των διπλωματικών εργασίων για το τρέχον ακαδημαιϊκό έτος.
</p>


<h3> Οδηγός Συγγραφής </h3>

<p>
  Στην <a href="http://lib.ece.ntua.gr/sindesmoi.htm">ιστοσελίδα</a>
  της Βιβλιοθήκη της σχολής μπορούν να βρεθούν:
  <ul>
    <li> 
         o Οδηγός Συγγραφής των διπλωματικών, διδακτορικών, μεταπτυχιακών. 
	(<a href="/diplom/guide/files/OdhgosSyggrafhs_v3.pdf">pdf</a>)
   </li>
    <li> 
          το Έντυπο ανάθεσης διπλωματικής εργασίας. 
          (<a href="/diplom/guide/files/entypo_anathesis_diplomatikis.pdf">pdf</a>,
          <a href="/diplom/guide/files/entypo_anathesis_diplomatikis.doc">doc</a>)

   </li>
  </ul>
<p>



<h3> Διάφορα </h3>

<ul>

  <li>
  Τυχόν κώδικας που περιλαμβάνεται
  στο κείμενο της διπλωματικής θα πρέπει να παρουσιάζεται με
  την γραμματοσειρά <tt>Courier</tt> ή κάποια άλλη <a
  href="http://en.wikipedia.org/wiki/Typeface#Proportion">Monospace</a>
  γραμματοσειρά.
  </li><li>
  Στις ιστοσελίδες που περιέχονται στην βιβλιογραφία καλό
  είναι να αναφέρεται και η ημερομηνία ανάγνωσης. Συγκεκριμένα
  για άρθρα της Wikipedia μπορούν να βρεθούν οδηγίες <a
  href="http://en.wikipedia.org/wiki/Wikipedia:Citing_Wikipedia">εδώ</a>.
  </li>

</ul>
</div>
  </div>