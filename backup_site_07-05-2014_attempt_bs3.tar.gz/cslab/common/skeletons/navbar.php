<?php
//load the available courses
$query = "SELECT Title, Alias FROM Courses WHERE LOWER(Level)='undergraduate'";
$result = mysqli_query($con, $query);
$pregrad = array();
while ($result != null && $row = mysqli_fetch_array($result)) {
    $pregrad [$row['Title']] = $row['Alias'];
}
$query = "SELECT Title, Alias FROM Courses WHERE LOWER(Level)='postgraduate'";
$result = mysqli_query($con, $query);
$postgrad = array();
while ($result != null && $row = mysqli_fetch_array($result)) {
    $postgrad[$row['Title']] = $row['Alias'];
}
?>    
<nav class="navbar navbar-default" role="navigation">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="<?php echo $server_root;?>" id="logo">
				<img src="<?php echo "$server_root/common/img/logo.png" ?>"> </a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li> <a href="<?php echo $server_root ?>">
                        <i class="icon-home pull-left"></i> Home</a>
                </li>
                <!-- "Research" Dropdown -->
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="icon-search pull-left"></i>Research <b class="caret"></b>
                    </a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="<?php echo $server_root ?>/research/"> 
                                <i class='icon-search'></i>Areas of Research</a> 
                        </li>
                        <li>
                            <a href="<?php echo $server_root ?>/publications/">
                                <i class='icon-globe'></i>Publications</a> 
                        </li>
                        <li>
                            <a href="<?php echo $server_root ?>/projects/">
                                <i class='icon-gears'></i>Projects </a> 
                        </li>
                        <li>
                            <a href="<?php echo $server_root ?>/diplom/">
                                <i class='icon-pencil'></i>Diploma Thesis</a>
                        </li>
                    </ul>
                </li>

                <!-- Courses Dropdown --> 
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="icon-book pull-left"></i>Courses <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li class="nav-header">Undergraduate</li>
                        <?php
                        foreach ($pregrad as $t => $a) {
                            echo "<li><a href='$server_root/courses/$a'>
			<i class='icon-book'></i>$t</a></li>";
                        }
                        ?>
                        <li class="divider"></li>
                        <li class="nav-header">Postgraduate</li>
                        <?php
                        foreach ($postgrad as $t => $a) {
                            echo "<li> <a href='$server_root/courses/$a'>
			  <i class='icon-book'></i>$t</a></li>";
                        }
                        ?>
                    </ul>
                </li>
                <!--END Cousrse Dropdown -->


                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="icon-globe pull-left"></i>Links <b class="caret"></b></a>
                    <ul class="dropdown-menu" id="quicklinks">
                        <?php include 'quick_links.html'; ?>
                    </ul>
                </li>
                <!-- END Quick Links Dropdown -->

                <!-- "About" Dropdown -->
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="icon-info-sign pull-left"></i>Profile<b class="caret"></b>
                    </a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="<?php echo $server_root ?>/staff/">
                                <i class='icon-user'></i>Staff </a>
                        </li>
                        <li>
                            <a href="<?php echo $server_root ?>/contact/">
                                <i class='icon-phone-sign'></i>Contact</a>
                        </li>
                    </ul>
                </li>
                <!--END "About" Dropdown -->
            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>