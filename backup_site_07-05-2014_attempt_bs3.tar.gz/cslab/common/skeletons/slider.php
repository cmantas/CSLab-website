<?php




?>


   

   
  <link rel='stylesheet' href='../common/css/nivo-slider.css' type='text/css' media='screen' />"
        <div id="slider-wrapper" class="span4">
        
            <div id="slider" class="nivoSlider" style="width:500px; height:200px">
                <img src="../common/img/computer_systems.jpg" alt="" title="#cslabcaption" />
		<img src="../common/img/distributed_system.jpg" alt="" title="#pdsgcaption" />
		<img src="../common/img/embedded_systems.jpg" alt="" title="#embedded_caption" />
            </div>
	<div id="embedded_caption" class="nivo-html-caption">
                <h2><a href="http://mule.cslab.ece.ntua.gr/">
				<strong>Embedded Systems Design Group</strong></a></h2>
        </div>
	<div id="cslabcaption" class="nivo-html-caption">
                <h2><a href="http://www.cslab.ece.ntua.gr/">
				<strong>Computing Systems Laboratory</strong></a></h2>
         </div>
	<div id="pdsgcaption" class="nivo-html-caption">
                <h2><a href="http://www.cslab.ece.ntua.gr/">
				<strong>Parallel and Distributed Systems Group</strong></a></h2>
         </div>
  

    </div>
 

