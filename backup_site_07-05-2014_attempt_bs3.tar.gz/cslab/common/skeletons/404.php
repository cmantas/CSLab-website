<style>
  .center {text-align: center; margin-left: auto; margin-right: auto; margin-bottom: auto; margin-top: auto;}
</style>
<title>Error 404</title>
<body>
  <div class="hero-unit center">
    <h1>Page Not Found <small><font face="Tahoma" color="red">Error 404</font></small></h1>
    <br />
    <p>The page you requested could not be found, please check your URL or contact your webmaster (I would not bother though). </p>
    <p><b>Or you could got to the home page of CSLab using this button:</b></p>
    <a href="<?php echo "$server_root"?>" class="btn btn-large btn-info"><i class="icon-home icon-white"></i> Take Me Home</a>
  </div>
  <br />
<div class="thumbnail">
  <center><h2> Other Links :</h2></center>
</div>
  <br />
  
  <div class="thumbnail span3 center">
    <h3>Google it maybe?</h3>
    <p> Search in google:</p>
    <div class="hero-unit">
	    <script src="//www.gmodules.com/ig/ifr?url=http://hosting.gmodules.com/ig/gadgets/file/107950459797439355026/CGS_Small_English.xml&amp;synd=open&amp;w=160&amp;h=60&amp;title=Google+Search&amp;border=%23ffffff%7C3px%2C1px+solid+%23999999&amp;output=js"></script>
    </div>
    <a href="http://www.google.com/" class="btn btn-danger btn-large"><i class="icon-share icon-white"></i> Google</a>
  </div>
  <div class="thumbnail span3 center">
    <h3>Or just kill some time...</h3>
    <div class="hero-unit">
	   <img src=" http://s.ytimg.com/yts/img/youtube_logo_stacked-vfl225ZTx.png"> 
    </div>
    <a href="http://www.youtube.com/" class="btn btn-danger btn-large"><i class="icon-share icon-white"></i>Youtube</a>
  </div>
  
    <div class="thumbnail span3 center">
    <h3>CSLab Publications</h3>
    <div class="hero-unit">
	   <img src="<?php echo "$server_root/common/img/research.png";?>"> 
    </div>
    <a href="<?php echo "$server_root/publications/";?>" class="btn btn-danger btn-large"><i class="icon-share icon-white"></i> Publications</a>
  </div> 
  <!-- By ConnerT HTML & CSS Enthusiast -->  