<?php
$course="dummy1";
$title="dummy course one lecture notes";

include "../lecture_notes.php";

?>
